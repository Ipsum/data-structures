#ifndef POINT_H
#define POINT_H

/*--------------- P o i n t . h ---------------*/

/*
by:   George Cheney
      ECE Department
      UMASS Lowell

PURPOSE
This is the interface for the module Point.cpp.

CHANGES:
0-30-2013 gpc -- Distributed to Fall 2013 16.322.
*/

#include <iostream>

using std::istream;
using std::ostream;

/*===== t y p e    d e f i n i t i o n s =====*/

/*--------------- t y p e    P o i n t ---------------*/

class Point
{
public:

   // Constructors
   Point () : defined(false) {}         // Default Constructor
   Point (const double xVal, const double yVal) :   // Explicit Constructor
       defined(true), x(xVal), y(yVal) {}

   // Accessors
   double X() const; // Returns x
   double Y() const; // Returns y
   bool Defined() const { return defined; } // Returns defined

   // Mutators
   void SetXY(const double xVal, const double yVal); // Sets (x, y)

   // Test for an intersection.
   bool Point::Intersection (const Point p1, const Point p2) const;

   void Show(ostream &os) const;
   void Get(istream &is);

private:
   bool  defined;                   // true if the point has been defined
   double x;                         // x coordinate
   double y;                         // y coordinate
};

// Input-Output Operators
istream & operator>>(istream &is, Point &p);
ostream & operator<<(ostream &os, const Point &p);

#endif
